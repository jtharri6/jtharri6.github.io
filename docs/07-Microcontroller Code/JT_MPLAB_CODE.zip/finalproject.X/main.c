 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include <stdint.h>
#include <xc.h>

adc_result_t adcraw;
float moist = 0;
float dry = 0;

uint32_t timer = 0;
uint32_t delaytime = 10000; // every 10 seconds
uint16_t drylimit = 70;

// debugging light timer
uint32_t blinkTimer = 0;
uint16_t blinkInterval = 300;   // ms

void main(void)
{
    SYSTEM_Initialize();
    
    printf("systemstart\n");
    led_SetLow();
    wpump_SetLow();
    lightsys_SetHigh();

    printf("systemstart\n");

    while (1)
    {
        // sensor setup
        ADC_ChannelSelect(0);    
        ADC_ConversionStart();
        while(!ADC_IsConversionDone());
        adcraw = ADC_ConversionResultGet();

        moist = (adcraw / 4095.0f) * 100.0f;
        dry = 100.0f - moist;

        __delay_ms(1000);
        timer += 1000;
        blinkTimer += 100;

        // debugging light
        if (blinkTimer >= blinkInterval)
        {
            led_Toggle();
            blinkTimer = 0;
        }

        // debugging button, resets timer
        if (button_GetValue() == 0)   
        {
            timer = 0;
            wpump_SetLow();
            printf("buttonpress\n");
            __delay_ms(200);           
        }

        // led dry led setup
        if (dry > drylimit)
        {
            // led on when dry
            led_SetHigh();

            if (timer >= delaytime)
            {
                printf("pumpstart\n");
                wpump_SetHigh();
                __delay_ms(2000);
                wpump_SetLow();
                printf("pumpstop\n");
                timer = 0;
            }
        }
        else
        {
            // when soil is wet turn LED OFF but blinking continues
        }

        printf("moist: %.1f | dry: %.1f | pump: %d\r\n",
               moist, dry, wpump_GetValue());
    }
}